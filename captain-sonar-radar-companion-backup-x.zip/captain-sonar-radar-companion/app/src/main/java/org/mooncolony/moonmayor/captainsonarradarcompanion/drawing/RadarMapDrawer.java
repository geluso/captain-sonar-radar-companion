package org.mooncolony.moonmayor.captainsonarradarcompanion.drawing;

import android.app.Activity;
import android.widget.ImageView;

import org.mooncolony.moonmayor.captainsonarradarcompanion.GameState;

public class RadarMapDrawer extends MapDrawer {
    public RadarMapDrawer(Activity activity, ImageView map, GameState gameState) {
        super(activity, map, gameState);
    }
}
